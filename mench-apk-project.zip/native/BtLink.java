package com.hasan.mench;
import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.*;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@SuppressLint("MissingPermission")
@CapacitorPlugin(name = "BtLink")
public class BtLink extends Plugin {
  static final UUID U = UUID.fromString("8a6f1d3e-5b7c-4e2a-9c1d-0f3b6a7e2c11");
  BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
  Map<String, PrintWriter> w = new ConcurrentHashMap<>();
  int n = 0;

  boolean ok(PluginCall c) {
    if (ad == null || !ad.isEnabled()) { c.reject("off"); return false; }
    if (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(getContext(), Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
      ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, 77);
      c.reject("perm"); return false;
    }
    return true;
  }

  String reg(final BluetoothSocket s) throws IOException {
    final String id = "b" + (++n);
    w.put(id, new PrintWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8")));
    JSObject o = new JSObject(); o.put("id", id); notifyListeners("conn", o);
    new Thread(() -> {
      try {
        BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
        String l;
        while ((l = r.readLine()) != null) { JSObject d = new JSObject(); d.put("id", id); d.put("msg", l); notifyListeners("data", d); }
      } catch (Exception e) {}
    }).start();
    return id;
  }

  @PluginMethod public void paired(PluginCall c) {
    if (!ok(c)) return;
    JSArray a = new JSArray();
    for (BluetoothDevice d : ad.getBondedDevices()) { JSObject o = new JSObject(); o.put("name", d.getName()); o.put("addr", d.getAddress()); a.put(o); }
    JSObject r = new JSObject(); r.put("list", a); c.resolve(r);
  }

  @PluginMethod public void listen(PluginCall c) {
    if (!ok(c)) return;
    new Thread(() -> {
      try { BluetoothServerSocket ss = ad.listenUsingRfcommWithServiceRecord("mench", U); while (true) reg(ss.accept()); } catch (Exception e) {}
    }).start();
    c.resolve();
  }

  @PluginMethod public void connect(PluginCall c) {
    if (!ok(c)) return;
    final String a = c.getString("addr");
    new Thread(() -> {
      try {
        ad.cancelDiscovery();
        BluetoothSocket s = ad.getRemoteDevice(a).createRfcommSocketToServiceRecord(U);
        s.connect();
        JSObject r = new JSObject(); r.put("id", reg(s)); c.resolve(r);
      } catch (Exception e) { c.reject("fail"); }
    }).start();
  }

  @PluginMethod public void send(PluginCall c) {
    PrintWriter p = w.get(c.getString("id"));
    if (p != null) synchronized (p) { p.println(c.getString("msg")); p.flush(); }
    c.resolve();
  }
}
