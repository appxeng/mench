1) این پوشه را در یک مخزن GitHub بگذار (branch: main).
2) تب Actions ← Build APK ← Run workflow.
3) بعد از ~۵ دقیقه، فایل mench-apk را از Artifacts دانلود کن (app-debug.apk).
by hasan.d
